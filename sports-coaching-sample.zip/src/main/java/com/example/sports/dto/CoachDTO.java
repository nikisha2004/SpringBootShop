package com.example.sports.dto;

public class CoachDTO {
    private Long id;
    private String name;

    public CoachDTO() {}

    public CoachDTO(Long id, String name) {
        this.id = id;
        this.name = name;
    }

    // getters / setters
    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }
}
