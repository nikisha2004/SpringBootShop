package com.example.sports.dto;

public class CustomerRequestDTO {
    private Integer height;
    private Integer weight;
    private Long coach_id;

    public CustomerRequestDTO() {}

    // getters / setters
    public Integer getHeight() {
        return height;
    }

    public Integer getWeight() {
        return weight;
    }

    public Long getCoach_id() {
        return coach_id;
    }

    public void setHeight(Integer height) {
        this.height = height;
    }

    public void setWeight(Integer weight) {
        this.weight = weight;
    }

    public void setCoach_id(Long coach_id) {
        this.coach_id = coach_id;
    }
}
