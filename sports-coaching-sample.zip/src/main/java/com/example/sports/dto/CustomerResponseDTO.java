package com.example.sports.dto;

public class CustomerResponseDTO {
    private Long id;
    private Integer height;
    private Integer weight;
    private CoachDTO coach;

    public CustomerResponseDTO() {}

    public CustomerResponseDTO(Long id, Integer height, Integer weight, CoachDTO coach) {
        this.id = id;
        this.height = height;
        this.weight = weight;
        this.coach = coach;
    }

    // getters / setters
    public Long getId() {
        return id;
    }

    public Integer getHeight() {
        return height;
    }

    public Integer getWeight() {
        return weight;
    }

    public CoachDTO getCoach() {
        return coach;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setHeight(Integer height) {
        this.height = height;
    }

    public void setWeight(Integer weight) {
        this.weight = weight;
    }

    public void setCoach(CoachDTO coach) {
        this.coach = coach;
    }
}
