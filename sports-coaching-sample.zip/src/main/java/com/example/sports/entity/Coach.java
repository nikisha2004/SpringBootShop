package com.example.sports.entity;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "coaches")
public class Coach {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    // Bidirectional mapping: One coach -> many customers
    @OneToMany(mappedBy = "coach", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Customer> customers = new ArrayList<>();

    public Coach() {}

    public Coach(String name) {
        this.name = name;
    }

    // getters and setters

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public List<Customer> getCustomers() {
        return customers;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCustomers(List<Customer> customers) {
        this.customers = customers;
    }

    // helper methods to maintain bidirectional relationship
    public void addCustomer(Customer customer) {
        customers.add(customer);
        customer.setCoach(this);
    }

    public void removeCustomer(Customer customer) {
        customers.remove(customer);
        customer.setCoach(null);
    }
}
