package com.example.sports.entity;

import javax.persistence.*;

@Entity
@Table(name = "customers")
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Integer height;

    private Integer weight;

    // Many customers can have the same coach
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "coach_id")
    private Coach coach;

    public Customer() {}

    public Customer(Integer height, Integer weight) {
        this.height = height;
        this.weight = weight;
    }

    // getters and setters

    public Long getId() {
        return id;
    }

    public Integer getHeight() {
        return height;
    }

    public Integer getWeight() {
        return weight;
    }

    public Coach getCoach() {
        return coach;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setHeight(Integer height) {
        this.height = height;
    }

    public void setWeight(Integer weight) {
        this.weight = weight;
    }

    public void setCoach(Coach coach) {
        this.coach = coach;
    }
}
