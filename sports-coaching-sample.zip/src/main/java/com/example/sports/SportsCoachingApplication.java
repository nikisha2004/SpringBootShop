package com.example.sports;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SportsCoachingApplication {
    public static void main(String[] args) {
        SpringApplication.run(SportsCoachingApplication.class, args);
    }
}
