package com.example.sports.controller;

import com.example.sports.dto.CoachDTO;
import com.example.sports.service.CoachService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/coach")
public class CoachController {

    private final CoachService coachService;

    public CoachController(CoachService coachService) {
        this.coachService = coachService;
    }

    @PostMapping
    public ResponseEntity<CoachDTO> createCoach(@RequestBody CoachDTO coachDTO) {
        CoachDTO created = coachService.createCoach(coachDTO);
        return ResponseEntity.created(URI.create("/api/coach/" + created.getId())).body(created);
    }

    @GetMapping
    public ResponseEntity<List<CoachDTO>> getAllCoaches() {
        return ResponseEntity.ok(coachService.getAllCoaches());
    }

    @GetMapping("/{id}")
    public ResponseEntity<CoachDTO> getCoach(@PathVariable Long id) {
        return ResponseEntity.ok(coachService.getCoachById(id));
    }
}
