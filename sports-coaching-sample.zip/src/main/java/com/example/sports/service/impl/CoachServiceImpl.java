package com.example.sports.service.impl;

import com.example.sports.dto.CoachDTO;
import com.example.sports.entity.Coach;
import com.example.sports.exception.ResourceNotFoundException;
import com.example.sports.repository.CoachRepository;
import com.example.sports.service.CoachService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CoachServiceImpl implements CoachService {

    private final CoachRepository coachRepository;

    public CoachServiceImpl(CoachRepository coachRepository) {
        this.coachRepository = coachRepository;
    }

    @Override
    public CoachDTO createCoach(CoachDTO coachDTO) {
        Coach coach = new Coach();
        coach.setName(coachDTO.getName());
        coach = coachRepository.save(coach);
        coachDTO.setId(coach.getId());
        return coachDTO;
    }

    @Override
    public List<CoachDTO> getAllCoaches() {
        return coachRepository.findAll().stream()
                .map(c -> new CoachDTO(c.getId(), c.getName()))
                .collect(Collectors.toList());
    }

    @Override
    public CoachDTO getCoachById(Long id) {
        Coach coach = coachRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Coach not found with id: " + id));
        return new CoachDTO(coach.getId(), coach.getName());
    }

    @Override
    public Coach getCoachEntityById(Long id) {
        return coachRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Coach not found with id: " + id));
    }
}
