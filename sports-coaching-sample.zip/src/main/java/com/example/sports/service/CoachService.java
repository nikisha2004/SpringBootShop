package com.example.sports.service;

import com.example.sports.dto.CoachDTO;
import com.example.sports.entity.Coach;

import java.util.List;

public interface CoachService {
    CoachDTO createCoach(CoachDTO coachDTO);
    List<CoachDTO> getAllCoaches();
    CoachDTO getCoachById(Long id);
    Coach getCoachEntityById(Long id);
}
