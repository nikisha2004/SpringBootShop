package com.example.sports.service.impl;

import com.example.sports.dto.CoachDTO;
import com.example.sports.dto.CustomerRequestDTO;
import com.example.sports.dto.CustomerResponseDTO;
import com.example.sports.entity.Coach;
import com.example.sports.entity.Customer;
import com.example.sports.exception.ResourceNotFoundException;
import com.example.sports.repository.CustomerRepository;
import com.example.sports.service.CoachService;
import com.example.sports.service.CustomerService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CustomerServiceImpl implements CustomerService {

    private final CustomerRepository customerRepository;
    private final CoachService coachService;

    public CustomerServiceImpl(CustomerRepository customerRepository, CoachService coachService) {
        this.customerRepository = customerRepository;
        this.coachService = coachService;
    }

    @Override
    public CustomerResponseDTO createCustomer(CustomerRequestDTO request) {
        Coach coach = coachService.getCoachEntityById(request.getCoach_id());
        Customer customer = new Customer(request.getHeight(), request.getWeight());
        // maintain bidirectional relationship
        coach.addCustomer(customer);
        customer = customerRepository.save(customer);
        CoachDTO coachDTO = new CoachDTO(coach.getId(), coach.getName());
        return new CustomerResponseDTO(customer.getId(), customer.getHeight(), customer.getWeight(), coachDTO);
    }

    @Override
    public List<CustomerResponseDTO> getAllCustomers() {
        return customerRepository.findAll().stream()
                .map(c -> {
                    Coach coach = c.getCoach();
                    CoachDTO coachDTO = coach == null ? null : new CoachDTO(coach.getId(), coach.getName());
                    return new CustomerResponseDTO(c.getId(), c.getHeight(), c.getWeight(), coachDTO);
                })
                .sorted((a,b) -> Long.compare(a.getId(), b.getId()))
                .collect(Collectors.toList());
    }

    @Override
    public CustomerResponseDTO getCustomerById(Long id) {
        Customer c = customerRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found with id: " + id));
        Coach coach = c.getCoach();
        CoachDTO coachDTO = coach == null ? null : new CoachDTO(coach.getId(), coach.getName());
        return new CustomerResponseDTO(c.getId(), c.getHeight(), c.getWeight(), coachDTO);
    }
}
