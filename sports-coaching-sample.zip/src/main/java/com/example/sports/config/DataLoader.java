package com.example.sports.config;

import com.example.sports.entity.Coach;
import com.example.sports.repository.CoachRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DataLoader {
    @Bean
    CommandLineRunner initDatabase(CoachRepository coachRepository) {
        return args -> {
            Coach c = new Coach();
            c.setName("Alex Doe");
            coachRepository.save(c);

            Coach c2 = new Coach();
            c2.setName("Sam");
            coachRepository.save(c2);
        };
    }
}
