# Sports Coaching - Spring Boot Sample

This is a small Spring Boot project implementing a Sports Coaching API per the assessment description.

Features:
- Entities: Coach and Customer with bidirectional mapping (Coach -> Customers).
- Endpoints:
  - POST /api/coach        -> create a coach (accepts { "name": "Alex Doe" })
  - GET  /api/coach        -> list all coaches
  - GET  /api/coach/{id}   -> get coach by id
  - POST /api/customer     -> create a customer (accepts { "height":180, "weight":80, "coach_id":1 })
  - GET  /api/customer     -> list all customers (sorted by id ascending)
  - GET  /api/customer/{id}-> get customer by id

Run:
- Build with Maven: `mvn clean package`
- Run: `mvn spring-boot:run` or run the generated jar.

Database:
- Uses H2 in-memory database by default. H2 console: `/h2-console`.

Notes:
- No Lombok used.
- Proper 201 Created responses for POST, 200 OK for successful GET, 404 Not Found for missing resources.
