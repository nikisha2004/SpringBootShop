SpringBootShop (STS-ready, no Lombok). Import as Maven project in STS.
