package com.springbootshop.config;
import org.springframework.context.annotation.Configuration; import org.springframework.context.annotation.Bean; import org.springframework.boot.CommandLineRunner; import com.springbootshop.user.UserRepository; import com.springbootshop.user.AppUser; import org.springframework.security.crypto.password.PasswordEncoder; import java.util.HashSet; import com.springbootshop.security.Role;
@Configuration
public class DataLoader {
    @Bean
    CommandLineRunner seedAdmin(UserRepository repo, PasswordEncoder encoder) {
        return args -> {
            repo.findByUsername("admin").orElseGet(() -> {
                AppUser admin = new AppUser();
                admin.setName("Admin"); admin.setEmail("admin@example.com"); admin.setUsername("admin"); admin.setPassword(encoder.encode("admin123")); java.util.Set<Role> roles = new HashSet<>(); roles.add(Role.ADMIN); roles.add(Role.USER); admin.setRoles(roles); return repo.save(admin);
            });
        };
    }
}

