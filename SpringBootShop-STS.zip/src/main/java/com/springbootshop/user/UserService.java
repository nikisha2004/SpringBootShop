package com.springbootshop.user;
import org.springframework.stereotype.Service; import org.springframework.security.crypto.password.PasswordEncoder; import java.util.List; import java.util.HashSet; import com.springbootshop.security.Role;
@Service
public class UserService {
    private final UserRepository repo; private final PasswordEncoder encoder;
    public UserService(UserRepository repo, PasswordEncoder encoder) { this.repo = repo; this.encoder = encoder; }
    public AppUser addUser(AppUser u) { u.setPassword(encoder.encode(u.getPassword())); if (u.getRoles()==null||u.getRoles().isEmpty()){ HashSet<Role> r=new HashSet<>(); r.add(Role.USER); u.setRoles(r);} return repo.save(u); }
    public AppUser updateUser(Long id, AppUser u) { AppUser e = repo.findById(id).orElseThrow(); e.setName(u.getName()); e.setAddress(u.getAddress()); e.setContactNumber(u.getContactNumber()); e.setEmail(u.getEmail()); if (u.getPassword()!=null && !u.getPassword().isBlank()) e.setPassword(encoder.encode(u.getPassword())); if (u.getRoles()!=null && !u.getRoles().isEmpty()) e.setRoles(u.getRoles()); return repo.save(e); }
    public void deleteUser(Long id) { repo.deleteById(id); }
    public AppUser getUserById(Long id) { return repo.findById(id).orElseThrow(); }
    public List<AppUser> getAll() { return repo.findAll(); }
}

