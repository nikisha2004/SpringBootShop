package com.springbootshop.order;
import org.springframework.web.bind.annotation.*; import org.springframework.http.ResponseEntity; import org.springframework.security.core.Authentication; import java.util.List;
@RestController
@RequestMapping("/api/orders")
public class OrderController {
    private final OrderService service; public OrderController(OrderService service) { this.service = service; }
    @PostMapping public ResponseEntity<Order> create(Authentication auth, @RequestBody CreateOrderRequest req) { return ResponseEntity.ok(service.createOrder(auth.getName(), req)); }
    @GetMapping public ResponseEntity<List<Order>> myOrders(Authentication auth) { return ResponseEntity.ok(service.getOrdersForUser(auth.getName())); }
}

