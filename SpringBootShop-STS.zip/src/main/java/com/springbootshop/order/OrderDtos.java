package com.springbootshop.order;
import java.util.List;
public class CreateOrderRequest { private List<Item> items; public static class Item { private Long productId; private int quantity; public Item(){} public Long getProductId(){return productId;} public void setProductId(Long p){this.productId=p;} public int getQuantity(){return quantity;} public void setQuantity(int q){this.quantity=q;} } public CreateOrderRequest(){} public List<Item> getItems(){return items;} public void setItems(List<Item> items){this.items=items;} }

