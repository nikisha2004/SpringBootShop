package com.springbootshop.order;
import org.springframework.stereotype.Service; import java.util.List; import java.math.BigDecimal; import com.springbootshop.product.ProductRepository; import com.springbootshop.user.UserRepository; import com.springbootshop.product.Product; import com.springbootshop.user.AppUser;
@Service
public class OrderService {
    private final OrderRepository orderRepo; private final ProductRepository productRepo; private final UserRepository userRepo;
    public OrderService(OrderRepository orderRepo, ProductRepository productRepo, UserRepository userRepo) { this.orderRepo = orderRepo; this.productRepo = productRepo; this.userRepo = userRepo; }
    public Order createOrder(String username, CreateOrderRequest req) { AppUser user = userRepo.findByUsername(username).orElseThrow(); Order order = new Order(); order.setUser(user); BigDecimal total = BigDecimal.ZERO; for (CreateOrderRequest.Item i : req.getItems()) { Product p = productRepo.findById(i.getProductId()).orElseThrow(); OrderItem oi = new OrderItem(); oi.setProduct(p); oi.setQuantity(i.getQuantity()); oi.setPrice(p.getPrice().multiply(new BigDecimal(i.getQuantity()))); order.getItems().add(oi); total = total.add(oi.getPrice()); } order.setTotal(total); return orderRepo.save(order); }
    public List<Order> getAllOrders() { return orderRepo.findAll(); }
    public List<Order> getOrdersForUser(String username) { AppUser user = userRepo.findByUsername(username).orElseThrow(); return orderRepo.findByUser(user); }
    public Order updateOrder(Long orderId, String status) { Order o = orderRepo.findById(orderId).orElseThrow(); o.setStatus(OrderStatus.valueOf(status)); return orderRepo.save(o); }
}

