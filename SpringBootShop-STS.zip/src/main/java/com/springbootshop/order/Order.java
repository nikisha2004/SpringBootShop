package com.springbootshop.order;

import com.springbootshop.user.AppUser;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "orders")
public class Order {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @ManyToOne private AppUser user;
    @Enumerated(EnumType.STRING) private OrderStatus status = OrderStatus.PENDING;
    private Instant createdAt = Instant.now();
    private Instant updatedAt = Instant.now();
    private BigDecimal total = BigDecimal.ZERO;
    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true) @JoinColumn(name = "order_id")
    private List<OrderItem> items = new ArrayList<>();
    public Order() {}
    public Long getId() { return id; } public void setId(Long id) { this.id = id; }
    public AppUser getUser() { return user; } public void setUser(AppUser user) { this.user = user; }
    public OrderStatus getStatus() { return status; } public void setStatus(OrderStatus status) { this.status = status; }
    public Instant getCreatedAt() { return createdAt; } public void setCreatedAt(Instant createdAt) { this.createdAt = createdAt; }
    public Instant getUpdatedAt() { return updatedAt; } public void setUpdatedAt(Instant updatedAt) { this.updatedAt = updatedAt; }
    public BigDecimal getTotal() { return total; } public void setTotal(BigDecimal total) { this.total = total; }
    public List<OrderItem> getItems() { return items; } public void setItems(List<OrderItem> items) { this.items = items; }
}

