package com.springbootshop.order;
public enum OrderStatus { PENDING, PAID, SHIPPED, DELIVERED, CANCELED }

