package com.springbootshop.product;
public enum Category { CLOTHING, ELECTRONICS, COSMETICS }

