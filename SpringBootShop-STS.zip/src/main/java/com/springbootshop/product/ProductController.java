package com.springbootshop.product;
import org.springframework.web.bind.annotation.*; import org.springframework.http.ResponseEntity; import java.util.List;
@RestController
@RequestMapping("/api/products")
public class ProductController {
    private final ProductService service; public ProductController(ProductService service) { this.service = service; }
    @GetMapping public ResponseEntity<List<Product>> getAll() { return ResponseEntity.ok(service.getAllProducts()); }
    @GetMapping("/{id}") public ResponseEntity<Product> getOne(@PathVariable Long id) { return ResponseEntity.ok(service.getSingleProduct(id)); }
    @GetMapping("/search") public ResponseEntity<List<Product>> search(@RequestParam String q) { return ResponseEntity.ok(service.getProductByName(q)); }
}

