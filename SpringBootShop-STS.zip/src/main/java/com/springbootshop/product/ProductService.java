package com.springbootshop.product;
import org.springframework.stereotype.Service; import java.util.List;
@Service
public class ProductService {
    private final ProductRepository repo;
    public ProductService(ProductRepository repo) { this.repo = repo; }
    public Product createProduct(Product p) { return repo.save(p); }
    public Product updateProductById(Long id, Product p) { Product e = repo.findById(id).orElseThrow(); e.setName(p.getName()); e.setStock(p.getStock()); e.setBrand(p.getBrand()); e.setCategory(p.getCategory()); e.setDescription(p.getDescription()); e.setPrice(p.getPrice()); e.setDiscount(p.getDiscount()); return repo.save(e); }
    public void deleteProduct(Long id) { repo.deleteById(id); }
    public List<Product> getAllProducts() { return repo.findAll(); }
    public Product getSingleProduct(Long id) { return repo.findById(id).orElseThrow(); }
    public List<Product> getProductByName(String name) { return repo.findByNameContainingIgnoreCase(name); }
}

