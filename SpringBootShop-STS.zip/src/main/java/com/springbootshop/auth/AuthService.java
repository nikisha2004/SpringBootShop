package com.springbootshop.auth;
import org.springframework.stereotype.Service; import org.springframework.security.crypto.password.PasswordEncoder; import com.springbootshop.user.UserRepository; import com.springbootshop.user.AppUser; import com.springbootshop.security.JwtService; import org.springframework.security.authentication.AuthenticationManager; import org.springframework.security.authentication.UsernamePasswordAuthenticationToken; import java.util.HashSet; import com.springbootshop.security.Role;
@Service
public class AuthService {
    private final UserRepository userRepo; private final PasswordEncoder encoder; private final AuthenticationManager authManager; private final JwtService jwtService;
    public AuthService(UserRepository userRepo, PasswordEncoder encoder, AuthenticationManager authManager, JwtService jwtService) { this.userRepo = userRepo; this.encoder = encoder; this.authManager = authManager; this.jwtService = jwtService; }
    public String signup(SignupRequest req) { if (userRepo.existsByUsername(req.getUsername())) throw new RuntimeException("Username taken"); if (userRepo.existsByEmail(req.getEmail())) throw new RuntimeException("Email taken"); AppUser u = new AppUser(); u.setName(req.getName()); u.setEmail(req.getEmail()); u.setUsername(req.getUsername()); u.setPassword(encoder.encode(req.getPassword())); u.setContactNumber(req.getContactNumber()); u.setAddress(req.getAddress()); HashSet<Role> roles = new HashSet<>(); roles.add(Role.USER); u.setRoles(roles); userRepo.save(u); return jwtService.generateToken(u); }
    public String login(AuthRequest req) { authManager.authenticate(new UsernamePasswordAuthenticationToken(req.getUsername(), req.getPassword())); AppUser u = userRepo.findByUsername(req.getUsername()).orElseThrow(); return jwtService.generateToken(u); }
}

