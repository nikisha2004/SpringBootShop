package com.springbootshop.auth;
import org.springframework.web.bind.annotation.*; import org.springframework.http.ResponseEntity;
@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final AuthService authService;
    public AuthController(AuthService authService) { this.authService = authService; }
    @PostMapping("/signup") public ResponseEntity<AuthResponse> signup(@RequestBody SignupRequest req) { String token = authService.signup(req); return ResponseEntity.ok(new AuthResponse(token)); }
    @PostMapping("/login") public ResponseEntity<AuthResponse> login(@RequestBody AuthRequest req) { String token = authService.login(req); return ResponseEntity.ok(new AuthResponse(token)); }
}

