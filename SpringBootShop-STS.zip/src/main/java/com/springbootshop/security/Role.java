package com.springbootshop.security;
public enum Role { USER, ADMIN }

