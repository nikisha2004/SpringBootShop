package com.springbootshop.security;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.security.Key;
import java.util.Date;
import java.util.Map;
import org.springframework.security.core.userdetails.UserDetails;

@Service
public class JwtService {
    @Value("${app.jwt.secret}") private String secret;
    @Value("${app.jwt.expiration}") private long expiration;
    private Key getSigningKey() { return Keys.hmacShaKeyFor(secret.getBytes()); }
    public String generateToken(UserDetails user) { return Jwts.builder().setSubject(user.getUsername()).addClaims(Map.of("roles", user.getAuthorities().toString())).setIssuedAt(new Date()).setExpiration(new Date(System.currentTimeMillis()+expiration)).signWith(getSigningKey(), SignatureAlgorithm.HS256).compact(); }
    public String extractUsername(String token) { return Jwts.parserBuilder().setSigningKey(getSigningKey()).build().parseClaimsJws(token).getBody().getSubject(); }
}

