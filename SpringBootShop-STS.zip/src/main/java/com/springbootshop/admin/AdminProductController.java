package com.springbootshop.admin;
import com.springbootshop.product.*;
import org.springframework.web.bind.annotation.*; import org.springframework.http.ResponseEntity; import org.springframework.security.access.prepost.PreAuthorize; import java.util.List;
@RestController
@RequestMapping("/api/admin/products")
@PreAuthorize("hasRole('ADMIN')")
public class AdminProductController {
    private final ProductService service; public AdminProductController(ProductService service) { this.service = service; }
    @PostMapping public ResponseEntity<Product> create(@RequestBody Product p) { return ResponseEntity.ok(service.createProduct(p)); }
    @PutMapping("/{id}") public ResponseEntity<Product> update(@PathVariable Long id, @RequestBody Product p) { return ResponseEntity.ok(service.updateProductById(id,p)); }
    @DeleteMapping("/{id}") public ResponseEntity<Void> delete(@PathVariable Long id) { service.deleteProduct(id); return ResponseEntity.noContent().build(); }
    @GetMapping public ResponseEntity<List<Product>> all() { return ResponseEntity.ok(service.getAllProducts()); }
}

