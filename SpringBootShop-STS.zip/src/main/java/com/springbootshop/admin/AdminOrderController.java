package com.springbootshop.admin;
import com.springbootshop.order.*;
import org.springframework.web.bind.annotation.*; import org.springframework.http.ResponseEntity; import org.springframework.security.access.prepost.PreAuthorize; import java.util.List;
@RestController
@RequestMapping("/api/admin/orders")
@PreAuthorize("hasRole('ADMIN')")
public class AdminOrderController {
    private final OrderService service; public AdminOrderController(OrderService service) { this.service = service; }
    @GetMapping public ResponseEntity<List<Order>> all() { return ResponseEntity.ok(service.getAllOrders()); }
    @PutMapping("/{orderId}") public ResponseEntity<Order> update(@PathVariable Long orderId, @RequestParam String status) { return ResponseEntity.ok(service.updateOrder(orderId,status)); }
}

