package com.springbootshop.admin;
import com.springbootshop.user.*;
import org.springframework.web.bind.annotation.*; import org.springframework.http.ResponseEntity; import org.springframework.security.access.prepost.PreAuthorize; import java.util.List;
@RestController
@RequestMapping("/api/admin/users")
@PreAuthorize("hasRole('ADMIN')")
public class AdminUserController {
    private final UserService service; public AdminUserController(UserService service) { this.service = service; }
    @PostMapping public ResponseEntity<AppUser> add(@RequestBody AppUser u) { return ResponseEntity.ok(service.addUser(u)); }
    @PutMapping("/{id}") public ResponseEntity<AppUser> update(@PathVariable Long id, @RequestBody AppUser u) { return ResponseEntity.ok(service.updateUser(id,u)); }
    @DeleteMapping("/{id}") public ResponseEntity<Void> delete(@PathVariable Long id) { service.deleteUser(id); return ResponseEntity.noContent().build(); }
    @GetMapping("/{id}") public ResponseEntity<AppUser> get(@PathVariable Long id) { return ResponseEntity.ok(service.getUserById(id)); }
    @GetMapping public ResponseEntity<List<AppUser>> all() { return ResponseEntity.ok(service.getAll()); }
}

